<?php
/**
 * ajax/proff.php — server-side proxy to proff.dk (bypasses CORS).
 *
 * ?action=suggest&q=kev        → GET https://www.proff.dk/api/search/omni/suggest?query=kev
 *                                returns { ok, titles: [{title, type}] }
 * ?action=search&q=KEV SERVICE ApS → GET https://www.proff.dk/_next/data/{buildId}/search.json?q=...
 *                                returns { ok, listingId, name }
 *
 * Input is validated + control chars stripped; nothing is written to disk.
 */
error_reporting(0);
require_once __DIR__ . '/../include/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$action = $_GET['action'] ?? '';
$q      = trim((string)($_GET['q'] ?? ''));

if (!in_array($action, ['suggest', 'search'], true)) {
    http_response_code(400);
    exit(json_encode(['ok' => false, 'error' => 'bad action']));
}

// Validate / normalize query
$q = preg_replace('/[\x00-\x1F\x7F]/u', '', $q);      // strip control chars
$q = mb_substr($q, 0, 120);                            // cap length
if ($q === '') {
    http_response_code(400);
    exit(json_encode(['ok' => false, 'error' => 'empty query']));
}

// ── proff.dk Next.js build id — auto-discovered + cached so deploys never break us ──
define('DEFAULT_BUILD_ID', '_-M00Z0BfYVjXDJL690YC');
define('BUILD_CACHE', __DIR__ . '/../data/build_id.json');
define('BUILD_CACHE_TTL', 21600); // 6 hours

function proff_http($url, $referer = 'https://www.proff.dk/') {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 12,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTPHEADER     => [
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36',
            'Accept: application/json, text/plain, */*',
            'Accept-Language: en-US,en;q=0.9',
            'Referer: ' . $referer
        ],
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['code' => $code, 'body' => $body];
}

function cached_build_id() {
    if (file_exists(BUILD_CACHE) && (time() - filemtime(BUILD_CACHE) < BUILD_CACHE_TTL)) {
        $j = json_decode(@file_get_contents(BUILD_CACHE), true);
        if (!empty($j['buildId'])) return $j['buildId'];
    }
    return null;
}

function discover_build_id() {
    $r = proff_http('https://www.proff.dk/');
    if ($r['code'] === 200 && preg_match('/"buildId":"([a-zA-Z0-9_-]+)"/', $r['body'], $m)) {
        @file_put_contents(BUILD_CACHE, json_encode(['buildId' => $m[1]]));
        return $m[1];
    }
    return null;
}

// ── SUGGEST ──
if ($action === 'suggest') {
    $r = proff_http('https://www.proff.dk/api/search/omni/suggest?query=' . rawurlencode($q));
    if ($r['code'] !== 200) {
        http_response_code(502);
        exit(json_encode(['ok' => false, 'error' => 'upstream ' . $r['code']]));
    }
    $data = json_decode($r['body'], true);
    if (!is_array($data)) {
        http_response_code(502);
        exit(json_encode(['ok' => false, 'error' => 'bad upstream json']));
    }
    $titles = [];
    foreach (($data['companies'] ?? []) as $c) {
        if (!empty($c['title'])) $titles[] = ['title' => (string)$c['title'], 'type' => $c['type'] ?? 'Company'];
    }
    // businessPersons intentionally excluded: they have no listingId/CVR.
    exit(json_encode(['ok' => true, 'titles' => $titles], JSON_UNESCAPED_UNICODE));
}

// ── SEARCH (with build-id auto-heal) ──
$buildId = cached_build_id() ?: DEFAULT_BUILD_ID;
$url = 'https://www.proff.dk/_next/data/' . $buildId . '/search.json?q=' . rawurlencode($q);
$r = proff_http($url, 'https://www.proff.dk/search');

// If the cached/hardcoded build is stale → 404. Re-discover and retry once.
if ($r['code'] === 404) {
    $fresh = discover_build_id();
    if ($fresh && $fresh !== $buildId) {
        $r = proff_http('https://www.proff.dk/_next/data/' . $fresh . '/search.json?q=' . rawurlencode($q), 'https://www.proff.dk/search');
    }
}

if ($r['code'] !== 200) {
    http_response_code(502);
    exit(json_encode(['ok' => false, 'error' => 'upstream ' . $r['code']]));
}
$body = $r['body'];

$data = json_decode($body, true);
if (!is_array($data)) {
    http_response_code(502);
    exit(json_encode(['ok' => false, 'error' => 'bad upstream json']));
}

/* ── SEARCH: extract listingId (CVR) ── */
$pp   = $data['pageProps'] ?? [];
$hd   = $pp['hydrationData'] ?? [];
$ss   = $hd['searchStore'] ?? [];
$pool = array_merge(
    is_array($ss['companies']['companies'] ?? null) ? $ss['companies']['companies'] : [],
    is_array($ss['inactiveCompanies'] ?? null)      ? $ss['inactiveCompanies']      : []
);

$match = null;
$want  = mb_strtolower($q);

// Prefer exact name match (case-insensitive)
foreach ($pool as $co) {
    if (!empty($co['name']) && mb_strtolower((string)$co['name']) === $want) {
        $match = $co;
        break;
    }
}
// Fallback: first company entry
if (!$match) {
    foreach ($pool as $co) {
        if (!empty($co['name'])) { $match = $co; break; }
    }
}

if ($match && !empty($match['listingId'])) {
    exit(json_encode([
        'ok'        => true,
        'listingId' => (string)$match['listingId'],
        'name'      => (string)($match['name'] ?? $q)
    ], JSON_UNESCAPED_UNICODE));
}

http_response_code(404);
exit(json_encode(['ok' => false, 'error' => 'no listingId found']));
