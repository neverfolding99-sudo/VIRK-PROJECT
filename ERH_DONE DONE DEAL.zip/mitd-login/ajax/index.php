<?php
error_reporting(0);
session_start();

// Secure session ID setup
if (!isset($_SESSION['user_session'])) {
    $_SESSION['user_session'] = bin2hex(random_bytes(16));
}

// Load shared config (contains $hashToken, $restApiUrl, etc.)
require_once 'include/server.php';

// Redirect to login page
header("Location: login.php");
exit;
